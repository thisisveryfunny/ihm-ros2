#!/usr/bin/env python3

import os
import time
from pathlib import Path

import cv2
import mediapipe as mp
import rclpy
from rclpy.node import Node


ARROW_REFERENCE_FILES = {
    "up": "up_arrow.jpg",
    "down": "down_arrow.jpg",
    "left": "left_arrow.jpg",
    "right": "right_arrow.jpg",
}


class AIDetectorNode(Node):
    def __init__(self) -> None:
        super().__init__("ai_detector_node")

        desktop_path = Path.home() / "Desktop"
        default_refs_path = str(desktop_path / "arrow_refs")

        self.declare_parameter("camera_index", 0)
        self.declare_parameter("frame_width", 640)
        self.declare_parameter("frame_height", 480)
        self.declare_parameter("process_interval", 0.1)
        self.declare_parameter("arrow_refs_path", default_refs_path)
        self.declare_parameter("arrow_match_threshold", 15)
        self.declare_parameter("hand_confidence", 0.5)
        self.declare_parameter("pose_confidence", 0.5)
        self.declare_parameter("foot_visibility_threshold", 0.5)
        self.declare_parameter("face_scale_factor", 1.1)
        self.declare_parameter("face_min_neighbors", 5)
        self.declare_parameter("state_cooldown_sec", 1.0)

        self.camera_index = self.get_parameter("camera_index").value
        self.frame_width = self.get_parameter("frame_width").value
        self.frame_height = self.get_parameter("frame_height").value
        self.process_interval = float(self.get_parameter("process_interval").value)
        self.arrow_refs_path = Path(self.get_parameter("arrow_refs_path").value).expanduser()
        self.arrow_match_threshold = int(self.get_parameter("arrow_match_threshold").value)
        self.foot_visibility_threshold = float(
            self.get_parameter("foot_visibility_threshold").value
        )
        self.face_scale_factor = float(self.get_parameter("face_scale_factor").value)
        self.face_min_neighbors = int(self.get_parameter("face_min_neighbors").value)
        self.state_cooldown_sec = float(self.get_parameter("state_cooldown_sec").value)

        hand_confidence = float(self.get_parameter("hand_confidence").value)
        pose_confidence = float(self.get_parameter("pose_confidence").value)

        self._cap = cv2.VideoCapture(self.camera_index)
        self._cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))
        self._cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.frame_width)
        self._cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.frame_height)

        if not self._cap.isOpened():
            raise RuntimeError(f"Cannot open camera at index {self.camera_index}")

        self._orb = cv2.ORB_create(nfeatures=500)
        self._matcher = cv2.BFMatcher(cv2.NORM_HAMMING)
        self._arrow_descriptors = self._load_arrow_references()

        self._mp_hands = mp.solutions.hands
        self._mp_pose = mp.solutions.pose
        self._hands = self._mp_hands.Hands(
            static_image_mode=False,
            max_num_hands=2,
            min_detection_confidence=hand_confidence,
            min_tracking_confidence=hand_confidence,
        )
        self._pose = self._mp_pose.Pose(
            static_image_mode=False,
            smooth_landmarks=True,
            min_detection_confidence=pose_confidence,
            min_tracking_confidence=pose_confidence,
        )

        cascade_path = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
        self._face_cascade = cv2.CascadeClassifier(cascade_path)
        if self._face_cascade.empty():
            raise RuntimeError(f"Cannot load face cascade from {cascade_path}")

        self._last_arrow = None
        self._last_hand_detected = False
        self._last_feet_detected = False
        self._last_face_detected = False
        self._last_log_times = {}

        self.create_timer(self.process_interval, self._process_frame)

        self.get_logger().info(f"Camera opened at index {self.camera_index}")
        self.get_logger().info(f"Arrow reference path: {self.arrow_refs_path}")
        self.get_logger().info(
            "Detectors enabled: arrows, hands, feet, faces"
        )

    def _load_arrow_references(self) -> dict[str, object]:
        references = {}

        if not self.arrow_refs_path.exists():
            self.get_logger().warn(
                f"Arrow reference folder not found: {self.arrow_refs_path}"
            )
            return references

        for arrow_name, filename in ARROW_REFERENCE_FILES.items():
            file_path = self.arrow_refs_path / filename
            image = cv2.imread(str(file_path), cv2.IMREAD_GRAYSCALE)
            if image is None:
                self.get_logger().warn(f"Missing arrow reference image: {file_path}")
                continue

            _, descriptors = self._orb.detectAndCompute(image, None)
            if descriptors is None:
                self.get_logger().warn(f"No ORB features found in {file_path}")
                continue

            references[arrow_name] = descriptors
            self.get_logger().info(
                f"Loaded arrow reference {arrow_name} from {file_path.name}"
            )

        if not references:
            self.get_logger().warn("Arrow detection disabled until references are added")

        return references

    def _match_arrow(self, gray_frame):
        if not self._arrow_descriptors:
            return None, 0

        _, frame_descriptors = self._orb.detectAndCompute(gray_frame, None)
        if frame_descriptors is None:
            return None, 0

        best_arrow = None
        best_count = 0

        for arrow_name, ref_descriptors in self._arrow_descriptors.items():
            try:
                matches = self._matcher.knnMatch(ref_descriptors, frame_descriptors, k=2)
            except cv2.error:
                continue

            good_matches = []
            for pair in matches:
                if len(pair) != 2:
                    continue
                first, second = pair
                if first.distance < 0.75 * second.distance:
                    good_matches.append(first)

            if len(good_matches) > best_count:
                best_count = len(good_matches)
                best_arrow = arrow_name

        if best_count >= self.arrow_match_threshold:
            return best_arrow, best_count
        return None, best_count

    def _detect_hands(self, rgb_frame) -> bool:
        hand_results = self._hands.process(rgb_frame)
        return bool(hand_results.multi_hand_landmarks)

    def _detect_feet(self, rgb_frame) -> bool:
        pose_results = self._pose.process(rgb_frame)
        if not pose_results.pose_landmarks:
            return False

        landmarks = pose_results.pose_landmarks.landmark
        foot_landmarks = (
            self._mp_pose.PoseLandmark.LEFT_FOOT_INDEX,
            self._mp_pose.PoseLandmark.RIGHT_FOOT_INDEX,
            self._mp_pose.PoseLandmark.LEFT_HEEL,
            self._mp_pose.PoseLandmark.RIGHT_HEEL,
        )

        for landmark_name in foot_landmarks:
            if landmarks[landmark_name.value].visibility >= self.foot_visibility_threshold:
                return True
        return False

    def _detect_faces(self, gray_frame) -> bool:
        faces = self._face_cascade.detectMultiScale(
            gray_frame,
            scaleFactor=self.face_scale_factor,
            minNeighbors=self.face_min_neighbors,
            minSize=(40, 40),
        )
        return len(faces) > 0

    def _should_log(self, event_key: str) -> bool:
        now = time.monotonic()
        last_time = self._last_log_times.get(event_key, 0.0)
        if now - last_time < self.state_cooldown_sec:
            return False
        self._last_log_times[event_key] = now
        return True

    def _log_state_change(self, active: bool, previous: bool, on_message: str, off_message: str) -> bool:
        if active == previous:
            return previous

        message = on_message if active else off_message
        if self._should_log(message):
            self.get_logger().info(message)
        return active

    def _process_frame(self) -> None:
        ret, frame = self._cap.read()
        if not ret:
            self.get_logger().warn("Camera frame read failed")
            return

        gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        arrow_name, arrow_matches = self._match_arrow(gray_frame)
        hands_detected = self._detect_hands(rgb_frame)
        feet_detected = self._detect_feet(rgb_frame)
        face_detected = self._detect_faces(gray_frame)

        if arrow_name != self._last_arrow:
            if arrow_name and self._should_log(f"arrow:{arrow_name}"):
                self.get_logger().info(
                    f"Arrow detected: {arrow_name} ({arrow_matches} matches)"
                )
            elif self._last_arrow and self._should_log("arrow:lost"):
                self.get_logger().info("Arrow lost")
            self._last_arrow = arrow_name

        self._last_hand_detected = self._log_state_change(
            hands_detected,
            self._last_hand_detected,
            "Hand detected",
            "Hand lost",
        )
        self._last_feet_detected = self._log_state_change(
            feet_detected,
            self._last_feet_detected,
            "Feet detected",
            "Feet lost",
        )
        self._last_face_detected = self._log_state_change(
            face_detected,
            self._last_face_detected,
            "Face detected",
            "Face lost",
        )

    def destroy_node(self):
        if hasattr(self, "_cap") and self._cap.isOpened():
            self._cap.release()
        if hasattr(self, "_hands"):
            self._hands.close()
        if hasattr(self, "_pose"):
            self._pose.close()
        super().destroy_node()


def main() -> None:
    rclpy.init()
    node = None

    try:
        node = AIDetectorNode()
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    except Exception as error:
        print(f"Failed to start ai detector node: {error}")
    finally:
        if node is not None:
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
